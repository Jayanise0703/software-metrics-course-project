"""SPBE automated tests."""
